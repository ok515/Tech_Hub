package com.example

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.Layer
import com.example.editor.CanvasViewModel
import com.example.editor.EditorBottomTab
import com.example.presentation.BottomNavigationBar
import com.example.presentation.CanvasView
import com.example.presentation.FloatingContextBar
import com.example.presentation.TopBar
import com.example.presentation.dialogs.AddMenuSheet
import com.example.presentation.dialogs.CanvasSettingsDialog
import com.example.presentation.dialogs.ExportDialog
import com.example.presentation.dialogs.LayersDrawer
import com.example.presentation.dialogs.QuotesSheet
import com.example.presentation.dialogs.TextEditDialog
import com.example.presentation.toolbars.BackgroundToolbar
import com.example.presentation.toolbars.DrawToolbar
import com.example.presentation.toolbars.ImageToolbar
import com.example.presentation.toolbars.ShapeToolbar
import com.example.presentation.toolbars.TextToolbar
import com.example.storage.AppLanguage
import com.example.ui.language.LocalAppStrings
import com.example.ui.language.getStringsForLanguage
import com.example.ui.theme.PikoneTheme

class MainActivity : ComponentActivity() {

    private val viewModel: CanvasViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.util.CrashLogger.init(applicationContext)
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val appStrings = remember(uiState.language) { getStringsForLanguage(uiState.language) }
            val layoutDirection = if (uiState.language == AppLanguage.ARABIC) LayoutDirection.Rtl else LayoutDirection.Ltr

            PikoneTheme(themeMode = uiState.themeMode) {
                CompositionLocalProvider(
                    LocalAppStrings provides appStrings,
                    LocalLayoutDirection provides layoutDirection
                ) {
                    PikoneApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun PikoneApp(viewModel: CanvasViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var editingTextLayer by remember { mutableStateOf<Layer.Text?>(null) }
    var showRestoreDialog by remember { mutableStateOf(viewModel.hasLastEdit()) }

    if (showRestoreDialog) {
        com.example.presentation.dialogs.RestoreDialog(
            timestamp = viewModel.getLastEditTimestamp(),
            onRestore = {
                viewModel.restoreLastEdit()
                showRestoreDialog = false
            },
            onStartNew = {
                viewModel.clearLastEdit()
                showRestoreDialog = false
            }
        )
    }

    val galleryPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                val inputStream = context.contentResolver.openInputStream(it)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                if (bitmap != null) {
                    viewModel.addImageLayer(bitmap, it.toString())
                    viewModel.selectTab(EditorBottomTab.IMAGES)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Toast feedback listener
    LaunchedEffect(uiState.messageToast) {
        uiState.messageToast?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    val selectedLayer = uiState.layers.find { it.id == uiState.selectedLayerId }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("pixel_craft_root_scaffold"),
        topBar = {
            AnimatedVisibility(
                visible = !uiState.isFocusMode,
                enter = fadeIn() + slideInVertically(initialOffsetY = { -it }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { -it })
            ) {
                TopBar(
                    viewModel = viewModel,
                    layerCount = uiState.layers.size,
                    canUndo = uiState.canUndo,
                    canRedo = uiState.canRedo,
                    isZoomMode = uiState.isZoomMode,
                    onEditSelectedLayer = {
                        if (selectedLayer is Layer.Text) {
                            editingTextLayer = selectedLayer
                        }
                    }
                )
            }
        },
        bottomBar = {
            AnimatedVisibility(
                visible = !uiState.isFocusMode,
                enter = fadeIn() + slideInVertically(initialOffsetY = { it }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { it })
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    // Active Tool Panel
                    AnimatedVisibility(
                        visible = uiState.activeBottomTab != EditorBottomTab.NONE,
                        enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
                        exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 })
                    ) {
                        when (uiState.activeBottomTab) {
                            EditorBottomTab.BACKGROUND_EFFECTS -> BackgroundToolbar(viewModel = viewModel, settings = uiState.settings)
                            EditorBottomTab.TEXT -> TextToolbar(
                                viewModel = viewModel,
                                selectedTextLayer = selectedLayer as? Layer.Text,
                                onEditTextContent = { textLayer -> editingTextLayer = textLayer }
                            )
                            EditorBottomTab.SHAPES -> ShapeToolbar(
                                viewModel = viewModel,
                                selectedShapeLayer = selectedLayer as? Layer.Shape
                            )
                            EditorBottomTab.IMAGES -> ImageToolbar(
                                viewModel = viewModel,
                                selectedImageLayer = selectedLayer as? Layer.Image
                            )
                            EditorBottomTab.DRAW -> DrawToolbar(viewModel = viewModel)
                            EditorBottomTab.NONE -> {}
                        }
                    }

                    // Bottom Navigation Bar
                    BottomNavigationBar(
                        activeTab = uiState.activeBottomTab,
                        onTabSelected = { tab -> viewModel.selectTab(tab) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Interactive Canvas
            CanvasView(
                viewModel = viewModel,
                settings = uiState.settings,
                layers = uiState.layers,
                selectedLayerId = uiState.selectedLayerId,
                isZoomMode = uiState.isZoomMode,
                onDoubleTapLayer = { layer ->
                    if (layer is Layer.Text) {
                        editingTextLayer = layer
                    }
                }
            )

            // Floating Quick Context Action Bar for Selected Elements
            if (!uiState.isFocusMode && selectedLayer != null && uiState.activeBottomTab == EditorBottomTab.NONE) {
                FloatingContextBar(
                    viewModel = viewModel,
                    selectedLayer = selectedLayer,
                    onEditText = if (selectedLayer is Layer.Text) { { editingTextLayer = selectedLayer } } else null,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 16.dp)
                )
            }

            // Smart Floating (+) Add Button
            if (!uiState.isFocusMode) {
                FloatingActionButton(
                    onClick = { viewModel.toggleAddMenuSheet(true) },
                    shape = CircleShape,
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    elevation = FloatingActionButtonDefaults.elevation(8.dp),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(bottom = 16.dp, start = 16.dp)
                        .testTag("smart_add_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Smart Add",
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Exit Focus Mode Overlay Button
            if (uiState.isFocusMode) {
                IconButton(
                    onClick = { viewModel.toggleFocusMode(false) },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                        .size(48.dp)
                        .background(
                            brush = Brush.radialGradient(listOf(Color(0xFF8B5CF6), Color(0xFF6366F1))),
                            shape = CircleShape
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = "Exit Focus Mode",
                        tint = Color.White
                    )
                }
            }
        }
    }

    // Modal Sheets and Dialogs
    if (uiState.showAddMenuSheet) {
        AddMenuSheet(
            viewModel = viewModel,
            onPickImageRequested = { galleryPickerLauncher.launch("image/*") },
            onDismiss = { viewModel.toggleAddMenuSheet(false) }
        )
    }

    if (uiState.showLayersDrawer) {
        LayersDrawer(
            viewModel = viewModel,
            layers = uiState.layers,
            selectedLayerId = uiState.selectedLayerId,
            onDismiss = { viewModel.toggleLayersDrawer(false) }
        )
    }

    if (uiState.showQuotesDialog) {
        QuotesSheet(
            viewModel = viewModel,
            onDismiss = { viewModel.toggleQuotesDialog(false) }
        )
    }

    if (uiState.showExportDialog) {
        ExportDialog(
            viewModel = viewModel,
            exportedFile = uiState.exportedFile,
            onDismiss = { viewModel.toggleExportDialog(false) }
        )
    }

    if (uiState.showSettingsDialog) {
        CanvasSettingsDialog(
            viewModel = viewModel,
            settings = uiState.settings,
            onDismiss = { viewModel.toggleSettingsDialog(false) }
        )
    }

    if (uiState.showStickerSheet) {
        com.example.presentation.dialogs.StickerPickerSheet(
            viewModel = viewModel,
            onDismiss = { viewModel.toggleStickerSheet(false) }
        )
    }

    if (uiState.showProjectsDialog) {
        com.example.presentation.dialogs.ProjectsDialog(
            viewModel = viewModel,
            onDismiss = { viewModel.toggleProjectsDialog(false) }
        )
    }

    if (uiState.showWhatsNewDialog) {
        com.example.presentation.dialogs.WhatsNewDialog(
            onDismiss = { viewModel.toggleWhatsNewDialog(false) }
        )
    }

    if (uiState.showAboutDialog) {
        com.example.presentation.dialogs.AboutDialog(
            onDismiss = { viewModel.toggleAboutDialog(false) }
        )
    }

    editingTextLayer?.let { textLayer ->
        TextEditDialog(
            initialText = textLayer.text,
            onConfirm = { updatedText ->
                viewModel.updateLayer(textLayer.copy(text = updatedText))
                editingTextLayer = null
            },
            onDismiss = { editingTextLayer = null }
        )
    }
}
