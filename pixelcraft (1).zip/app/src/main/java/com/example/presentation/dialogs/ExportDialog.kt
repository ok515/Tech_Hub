package com.example.presentation.dialogs

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ads.AdManager
import com.example.ads.AdMobBannerView
import com.example.editor.CanvasViewModel
import com.example.storage.ExportFormat
import com.example.ui.language.LocalAppStrings
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

data class QualityPreset(
    val label: String,
    val scale: Float,
    val isLocked: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportDialog(
    viewModel: CanvasViewModel,
    exportedFile: File?,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val coroutineScope = rememberCoroutineScope()
    val uiState by viewModel.uiState.collectAsState()

    var selectedFormat by remember { mutableStateOf(ExportFormat.PNG) }
    var scaleFactor by remember { mutableFloatStateOf(1f) }
    var quality by remember { mutableFloatStateOf(90f) }

    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableFloatStateOf(0f) }

    val qualityPresets = listOf(
        QualityPreset("Normal (1x)", 1f, isLocked = false),
        QualityPreset("HD (1.5x)", 1.5f, isLocked = true),
        QualityPreset("Full HD (2x)", 2f, isLocked = true),
        QualityPreset("2K (3x)", 3f, isLocked = true),
        QualityPreset("4K (4x)", 4f, isLocked = true)
    )

    val currentPreset = qualityPresets.find { it.scale == scaleFactor } ?: qualityPresets.first()

    val currentWidth = (uiState.settings.width * scaleFactor).toInt()
    val currentHeight = (uiState.settings.height * scaleFactor).toInt()

    fun getEstimatedSizeString(): String {
        val pixels = currentWidth.toLong() * currentHeight.toLong()
        val bytes = when (selectedFormat) {
            ExportFormat.PNG -> (pixels * 1.8).toLong()
            ExportFormat.JPG -> (pixels * 3.0 * (quality / 100f) * 0.22).toLong()
            ExportFormat.WEBP -> (pixels * 3.0 * (quality / 100f) * 0.16).toLong()
        }
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        return if (mb >= 1.0) {
            String.format(Locale.US, "~%.1f MB", mb)
        } else {
            String.format(Locale.US, "~%d KB", kb.toInt().coerceAtLeast(10))
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.testTag("export_dialog_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    strings.exportTitle,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = strings.close, modifier = Modifier.size(18.dp))
                }
            }

            // Compact Banner Ad
            AdMobBannerView(modifier = Modifier.height(44.dp))

            if (isExporting) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "${(exportProgress * 100).toInt()}%",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { exportProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp),
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            } else {
                // Section 1: File Format Selection
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(strings.exportFormat, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ExportFormat.entries.forEach { format ->
                            FilterChip(
                                selected = selectedFormat == format,
                                onClick = { selectedFormat = format },
                                label = { Text(format.name, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                modifier = Modifier.height(32.dp)
                            )
                        }
                    }
                }

                // Section 2: Quality Preset Selection
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.quality, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (currentPreset.isLocked) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("تتطلب مشاهدة إعلان 🎁", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        qualityPresets.forEach { preset ->
                            FilterChip(
                                selected = scaleFactor == preset.scale,
                                onClick = { scaleFactor = preset.scale },
                                label = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(preset.label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                        if (preset.isLocked) {
                                            Spacer(modifier = Modifier.width(2.dp))
                                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(10.dp))
                                        }
                                    }
                                },
                                modifier = Modifier.height(32.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = if (preset.isLocked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
                                )
                            )
                        }
                    }
                }

                // Section 3: Live Image Dimensions & Estimated File Size Display
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📐 الأبعاد: ${currentWidth} × ${currentHeight} px",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "💾 الحجم المتوقع: ${getEstimatedSizeString()}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                // Section 4: Compression Quality Slider (JPG/WEBP)
                if (selectedFormat != ExportFormat.PNG) {
                    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("نسبة الضغط:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${quality.toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                        Slider(
                            value = quality,
                            onValueChange = { quality = it },
                            valueRange = 30f..100f,
                            modifier = Modifier.height(28.dp)
                        )
                    }
                }

                // Section 5: Watermark Removal Card
                val isWatermarkRemoved = viewModel.isWatermarkRemoved()
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isWatermarkRemoved) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.HighQuality,
                                contentDescription = null,
                                tint = if (isWatermarkRemoved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isWatermarkRemoved) "✅ العلامة المائية غير مفعّلة" else "العلامة المائية (Created with Pikone)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        if (!isWatermarkRemoved) {
                            OutlinedButton(
                                onClick = {
                                    if (context is Activity) {
                                        AdManager.showRewardedAd(
                                            activity = context,
                                            onRewarded = { viewModel.activateWatermarkBypass(30) },
                                            onDismissedOrFailed = { }
                                        )
                                    } else {
                                        viewModel.activateWatermarkBypass(30)
                                    }
                                },
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text("إزالة 🎁", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Text(
                    "📁 الحفظ داخل: Pictures/Pikone",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Section 6: Action Buttons Row (Always Anchored at Bottom)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Export & Save Button
                    Button(
                        onClick = {
                            val startExportProcess = {
                                coroutineScope.launch {
                                    isExporting = true
                                    exportProgress = 0.2f
                                    delay(100)
                                    exportProgress = 0.6f
                                    delay(100)
                                    exportProgress = 0.9f
                                    viewModel.exportCanvasImage(selectedFormat, scaleFactor, quality.toInt())
                                    exportProgress = 1.0f
                                    delay(100)
                                    isExporting = false
                                    onDismiss()
                                }
                            }

                            if (currentPreset.isLocked && context is Activity) {
                                AdManager.showRewardedAd(
                                    activity = context,
                                    onRewarded = {
                                        startExportProcess()
                                    },
                                    onDismissedOrFailed = {
                                        Toast.makeText(context, "تم إلغاء التصدير: يلزم مشاهدة الإعلان كاملاً لتصدير الجودة العالية", Toast.LENGTH_LONG).show()
                                    }
                                )
                            } else {
                                startExportProcess()
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (currentPreset.isLocked) "تصدير بالجودة العالية 🎁" else strings.saveToGallery, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    // Share Button
                    OutlinedButton(
                        onClick = {
                            val startShareProcess = {
                                coroutineScope.launch {
                                    viewModel.exportCanvasImage(selectedFormat, scaleFactor, quality.toInt())
                                    viewModel.shareExportedImage()
                                    onDismiss()
                                }
                            }

                            if (currentPreset.isLocked && context is Activity) {
                                AdManager.showRewardedAd(
                                    activity = context,
                                    onRewarded = {
                                        startShareProcess()
                                    },
                                    onDismissedOrFailed = {
                                        Toast.makeText(context, "تم إلغاء التصدير: يلزم مشاهدة الإعلان كاملاً لتصدير الجودة العالية", Toast.LENGTH_LONG).show()
                                    }
                                )
                            } else {
                                startShareProcess()
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.shareImage, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
