package com.example.presentation

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Hexagon
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.editor.EditorBottomTab
import com.example.ui.language.LocalAppStrings

@Composable
fun BottomNavigationBar(
    activeTab: EditorBottomTab,
    onTabSelected: (EditorBottomTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val primaryColor = MaterialTheme.colorScheme.primary

    NavigationBar(
        modifier = modifier
            .fillMaxWidth()
            .height(64.dp)
            .testTag("bottom_navigation_bar"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        // Tab 1: Presets
        NavigationBarItem(
            selected = activeTab == EditorBottomTab.BACKGROUND_EFFECTS,
            onClick = { onTabSelected(EditorBottomTab.BACKGROUND_EFFECTS) },
            icon = { Icon(Icons.Default.Palette, contentDescription = strings.tabPresets) },
            label = { Text(strings.tabPresets, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = primaryColor,
                selectedTextColor = primaryColor,
                indicatorColor = primaryColor.copy(alpha = 0.15f),
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("tab_presets")
        )

        // Tab 2: Text
        NavigationBarItem(
            selected = activeTab == EditorBottomTab.TEXT,
            onClick = { onTabSelected(EditorBottomTab.TEXT) },
            icon = { Icon(Icons.Default.TextFields, contentDescription = strings.tabText) },
            label = { Text(strings.tabText, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = primaryColor,
                selectedTextColor = primaryColor,
                indicatorColor = primaryColor.copy(alpha = 0.15f),
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("tab_text")
        )

        // Tab 3: Shapes
        NavigationBarItem(
            selected = activeTab == EditorBottomTab.SHAPES,
            onClick = { onTabSelected(EditorBottomTab.SHAPES) },
            icon = { Icon(Icons.Default.Hexagon, contentDescription = strings.tabShapes) },
            label = { Text(strings.tabShapes, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = primaryColor,
                selectedTextColor = primaryColor,
                indicatorColor = primaryColor.copy(alpha = 0.15f),
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("tab_shapes")
        )

        // Tab 4: Background
        NavigationBarItem(
            selected = activeTab == EditorBottomTab.IMAGES,
            onClick = { onTabSelected(EditorBottomTab.IMAGES) },
            icon = { Icon(Icons.Default.Layers, contentDescription = strings.tabBackground) },
            label = { Text(strings.tabBackground, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = primaryColor,
                selectedTextColor = primaryColor,
                indicatorColor = primaryColor.copy(alpha = 0.15f),
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("tab_background")
        )

        // Tab 5: Effects
        NavigationBarItem(
            selected = activeTab == EditorBottomTab.DRAW,
            onClick = { onTabSelected(EditorBottomTab.DRAW) },
            icon = { Icon(Icons.Default.AutoFixHigh, contentDescription = strings.tabEffects) },
            label = { Text(strings.tabEffects, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = primaryColor,
                selectedTextColor = primaryColor,
                indicatorColor = primaryColor.copy(alpha = 0.15f),
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("tab_effects")
        )
    }
}



