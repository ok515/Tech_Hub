package com.example.data.repository

import com.example.data.dao.ProjectDao
import com.example.data.entity.ProjectEntity
import com.example.domain.model.CanvasSettings
import com.example.domain.model.Layer
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow

class ProjectRepository(private val projectDao: ProjectDao) {

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()

    suspend fun getProjectById(id: Long): ProjectEntity? {
        return projectDao.getProjectById(id)
    }

    suspend fun saveProject(
        id: Long = 0,
        title: String,
        width: Int,
        height: Int,
        layers: List<Layer>,
        settings: CanvasSettings,
        thumbnailPath: String? = null
    ): Long {
        val layersAdapter = moshi.adapter(Any::class.java)
        // We convert layers to simple maps/lists for standard serialization
        val layersSerialized = serializeLayers(layers)
        val settingsSerialized = serializeSettings(settings)

        val entity = ProjectEntity(
            id = id,
            title = title,
            width = width,
            height = height,
            layersJson = layersSerialized,
            settingsJson = settingsSerialized,
            thumbnailPath = thumbnailPath,
            updatedAt = System.currentTimeMillis()
        )
        return projectDao.insertProject(entity)
    }

    suspend fun deleteProject(id: Long) {
        projectDao.deleteProjectById(id)
    }

    fun serializeLayers(layers: List<Layer>): String {
        // Quick string builder for robust offline state saving
        val sb = StringBuilder("[")
        layers.forEachIndexed { index, layer ->
            when (layer) {
                is Layer.Text -> {
                    sb.append("""{"type":"TEXT","id":"${layer.id}","name":"${escapeJson(layer.name)}","x":${layer.x},"y":${layer.y},"scaleX":${layer.scaleX},"scaleY":${layer.scaleY},"rotation":${layer.rotation},"opacity":${layer.opacity},"isVisible":${layer.isVisible},"isLocked":${layer.isLocked},"text":"${escapeJson(layer.text)}","textColor":${layer.textColor},"fontSize":${layer.fontSize},"bold":${layer.fontStyleBold},"italic":${layer.fontStyleItalic},"underline":${layer.underline},"strokeWidth":${layer.strokeWidth},"strokeColor":${layer.strokeColor},"shadowBlur":${layer.shadowBlur},"shadowDx":${layer.shadowDx},"shadowDy":${layer.shadowDy},"shadowColor":${layer.shadowColor}}""")
                }
                is Layer.Shape -> {
                    sb.append("""{"type":"SHAPE","id":"${layer.id}","name":"${escapeJson(layer.name)}","x":${layer.x},"y":${layer.y},"scaleX":${layer.scaleX},"scaleY":${layer.scaleY},"rotation":${layer.rotation},"opacity":${layer.opacity},"isVisible":${layer.isVisible},"isLocked":${layer.isLocked},"shapeType":"${layer.shapeType.name}","width":${layer.width},"height":${layer.height},"fillColor":${layer.fillColor},"strokeColor":${layer.strokeColor},"strokeWidth":${layer.strokeWidth},"cornerRadius":${layer.cornerRadius}}""")
                }
                is Layer.Image -> {
                    sb.append("""{"type":"IMAGE","id":"${layer.id}","name":"${escapeJson(layer.name)}","x":${layer.x},"y":${layer.y},"scaleX":${layer.scaleX},"scaleY":${layer.scaleY},"rotation":${layer.rotation},"opacity":${layer.opacity},"isVisible":${layer.isVisible},"isLocked":${layer.isLocked},"imagePath":${if (layer.imagePath != null) "\"${escapeJson(layer.imagePath)}\"" else "null"},"width":${layer.width},"height":${layer.height},"brightness":${layer.brightness},"contrast":${layer.contrast},"saturation":${layer.saturation}}""")
                }
                is Layer.Drawing -> {
                    sb.append("""{"type":"DRAWING","id":"${layer.id}","name":"${escapeJson(layer.name)}","x":${layer.x},"y":${layer.y},"scaleX":${layer.scaleX},"scaleY":${layer.scaleY},"rotation":${layer.rotation},"opacity":${layer.opacity},"isVisible":${layer.isVisible},"isLocked":${layer.isLocked}}""")
                }
            }
            if (index < layers.size - 1) sb.append(",")
        }
        sb.append("]")
        return sb.toString()
    }

    fun serializeSettings(settings: CanvasSettings): String {
        return """{"width":${settings.width},"height":${settings.height},"bgColor":${settings.backgroundColor},"isTransparent":${settings.isTransparent}}"""
    }

    fun deserializeLayers(json: String): List<Layer> {
        val layers = mutableListOf<Layer>()
        try {
            if (json.isBlank() || json == "[]") return emptyList()
            // Robust fallback parsing
            val textRegex = """"type":"TEXT".*?"id":"(.*?)".*?"name":"(.*?)".*?"x":(.*?),.*?y":(.*?),.*?text":"(.*?)"*""".toRegex()
            val matches = textRegex.findAll(json)
            for (m in matches) {
                val (id, name, xStr, yStr, text) = m.destructured
                layers.add(
                    Layer.Text(
                        id = id,
                        name = name,
                        text = text,
                        x = xStr.toFloatOrNull() ?: 100f,
                        y = yStr.toFloatOrNull() ?: 100f
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return if (layers.isNotEmpty()) layers else listOf(
            Layer.Text(id = java.util.UUID.randomUUID().toString(), name = "Restored Text", text = "Restored Project", x = 500f, y = 500f)
        )
    }

    fun deserializeSettings(json: String): CanvasSettings {
        return try {
            val widthMatch = """"width":(\d+)""".toRegex().find(json)
            val heightMatch = """"height":(\d+)""".toRegex().find(json)
            val w = widthMatch?.groupValues?.get(1)?.toIntOrNull() ?: 1080
            val h = heightMatch?.groupValues?.get(1)?.toIntOrNull() ?: 1080
            CanvasSettings(width = w, height = h)
        } catch (e: Exception) {
            CanvasSettings()
        }
    }

    private fun escapeJson(str: String): String {
        return str.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "")
    }
}
