package com.example.storage

import android.content.Context
import android.content.SharedPreferences

enum class ThemeMode(val code: String, val displayNameAr: String, val displayNameEn: String) {
    SYSTEM("SYSTEM", "افتراضي النظام", "System Default"),
    LIGHT("LIGHT", "فاتح", "Light Mode"),
    DARK("DARK", "داكن", "Dark Mode")
}

enum class AppLanguage(val code: String, val nativeName: String, val isRtl: Boolean) {
    ARABIC("ar", "العربية", true),
    ENGLISH("en", "English", false),
    FRENCH("fr", "Français", false),
    SPANISH("es", "Español", false),
    TURKISH("tr", "Türkçe", false),
    GERMAN("de", "Deutsch", false),
    ITALIAN("it", "Italiano", false),
    RUSSIAN("ru", "Русский", false),
    PORTUGUESE("pt", "Português", false),
    INDONESIAN("id", "Bahasa Indonesia", false);

    companion object {
        fun fromCode(code: String): AppLanguage {
            return entries.find { it.code.equals(code, ignoreCase = true) } ?: ARABIC
        }
    }
}

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("pixelcraft_settings", Context.MODE_PRIVATE)

    var themeMode: ThemeMode
        get() {
            val saved = prefs.getString("theme_mode", ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name
            return try {
                ThemeMode.valueOf(saved)
            } catch (e: Exception) {
                ThemeMode.SYSTEM
            }
        }
        set(value) {
            prefs.edit().putString("theme_mode", value.name).apply()
        }

    var language: AppLanguage
        get() {
            val code = prefs.getString("app_language", AppLanguage.ARABIC.code) ?: AppLanguage.ARABIC.code
            return AppLanguage.fromCode(code)
        }
        set(value) {
            prefs.edit().putString("app_language", value.code).apply()
        }

    var lastEditLayersJson: String?
        get() = prefs.getString("last_edit_layers_json", null)
        set(value) = prefs.edit().putString("last_edit_layers_json", value).apply()

    var lastEditSettingsJson: String?
        get() = prefs.getString("last_edit_settings_json", null)
        set(value) = prefs.edit().putString("last_edit_settings_json", value).apply()

    var lastEditTimestamp: Long
        get() = prefs.getLong("last_edit_timestamp", 0L)
        set(value) = prefs.edit().putLong("last_edit_timestamp", value).apply()
}
